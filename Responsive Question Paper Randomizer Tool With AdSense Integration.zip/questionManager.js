// Question Manager Module for Question Randomizer Tool

class QuestionManager {
    constructor() {
        this.chapters = [];
        this.selectedQuestions = [];
        this.selectionConfig = {};
        this.initializeEventListeners();
    }

    /**
     * Initialize event listeners for question management
     */
    initializeEventListeners() {
        // Back to upload button
        const backToUploadBtn = document.getElementById('back-to-upload-btn');
        if (backToUploadBtn) {
            backToUploadBtn.addEventListener('click', () => {
                this.backToUpload();
            });
        }

        // Generate paper button
        const generatePaperBtn = document.getElementById('generate-paper-btn');
        if (generatePaperBtn) {
            generatePaperBtn.addEventListener('click', () => {
                this.generatePaper();
            });
        }
    }

    /**
     * Load chapters data
     * @param {Array} chapters - Array of chapter objects
     */
    loadChapters(chapters) {
        this.chapters = chapters || [];
        
        // Try to load from storage if no chapters provided
        if (this.chapters.length === 0) {
            const storedChapters = loadFromStorage('questionRandomizer_chapters');
            if (storedChapters) {
                this.chapters = storedChapters;
            }
        }

        this.renderChaptersList();
        this.updateSelectionSummary();
    }

    /**
     * Render the chapters list interface
     */
    renderChaptersList() {
        const container = document.getElementById('chapters-list');
        
        if (this.chapters.length === 0) {
            container.innerHTML = `
                <div class="no-chapters">
                    <i class="fas fa-folder-open"></i>
                    <h4>No Chapters Available</h4>
                    <p>Please upload and process Word files first.</p>
                    <button class="btn btn-primary" onclick="questionManager.backToUpload()">
                        <i class="fas fa-upload"></i>
                        Upload Files
                    </button>
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <div class="chapters-header">
                <h4>Select Questions by Chapter</h4>
                <p>Choose how many questions to include from each chapter</p>
            </div>
            <div class="chapters-container">
                ${this.chapters.map(chapter => this.renderChapterItem(chapter)).join('')}
            </div>
            <div class="selection-actions">
                <button class="btn btn-secondary" onclick="questionManager.selectAllChapters()">
                    <i class="fas fa-check-double"></i>
                    Select All
                </button>
                <button class="btn btn-secondary" onclick="questionManager.clearAllSelections()">
                    <i class="fas fa-times"></i>
                    Clear All
                </button>
                <button class="btn btn-info" onclick="questionManager.previewQuestions()">
                    <i class="fas fa-eye"></i>
                    Preview Questions
                </button>
            </div>
        `;
    }

    /**
     * Render a single chapter item
     * @param {Object} chapter - Chapter object
     * @returns {string} HTML string
     */
    renderChapterItem(chapter) {
        const currentSelection = this.selectionConfig[chapter.id] || 0;
        
        return `
            <div class="chapter-item" data-chapter-id="${chapter.id}">
                <div class="chapter-header">
                    <div class="chapter-info">
                        <h5 class="chapter-title">${chapter.name}</h5>
                        <div class="chapter-meta">
                            <span class="chapter-count">${chapter.totalQuestions} questions</span>
                            <span class="chapter-file">from ${chapter.fileName}</span>
                        </div>
                    </div>
                    <div class="chapter-toggle">
                        <label class="toggle-switch">
                            <input type="checkbox" 
                                   ${currentSelection > 0 ? 'checked' : ''} 
                                   onchange="questionManager.toggleChapter('${chapter.id}', this.checked)">
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                </div>
                
                <div class="chapter-content ${currentSelection > 0 ? 'active' : ''}">
                    <div class="question-selector">
                        <label for="questions-${chapter.id}">Number of questions to select:</label>
                        <div class="selector-controls">
                            <input type="range" 
                                   id="range-${chapter.id}"
                                   min="0" 
                                   max="${chapter.totalQuestions}" 
                                   value="${currentSelection}"
                                   oninput="questionManager.updateQuestionCount('${chapter.id}', this.value)">
                            <input type="number" 
                                   id="number-${chapter.id}"
                                   min="0" 
                                   max="${chapter.totalQuestions}" 
                                   value="${currentSelection}"
                                   onchange="questionManager.updateQuestionCount('${chapter.id}', this.value)">
                            <span class="max-label">/ ${chapter.totalQuestions}</span>
                        </div>
                    </div>
                    
                    <div class="question-preview">
                        <button class="btn btn-outline btn-sm" onclick="questionManager.showChapterQuestions('${chapter.id}')">
                            <i class="fas fa-list"></i>
                            View Questions
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * Toggle chapter selection
     * @param {string} chapterId - Chapter ID
     * @param {boolean} enabled - Whether chapter is enabled
     */
    toggleChapter(chapterId, enabled) {
        const chapter = this.chapters.find(c => c.id === chapterId);
        if (!chapter) return;

        const chapterElement = document.querySelector(`[data-chapter-id="${chapterId}"]`);
        const contentElement = chapterElement.querySelector('.chapter-content');
        
        if (enabled) {
            // Enable chapter and set default selection
            const defaultCount = Math.min(5, chapter.totalQuestions);
            this.selectionConfig[chapterId] = defaultCount;
            
            // Update UI
            contentElement.classList.add('active');
            chapterElement.querySelector(`#range-${chapterId}`).value = defaultCount;
            chapterElement.querySelector(`#number-${chapterId}`).value = defaultCount;
        } else {
            // Disable chapter
            this.selectionConfig[chapterId] = 0;
            contentElement.classList.remove('active');
        }

        this.updateSelectionSummary();
        this.updateGenerateButton();
    }

    /**
     * Update question count for a chapter
     * @param {string} chapterId - Chapter ID
     * @param {number} count - Number of questions
     */
    updateQuestionCount(chapterId, count) {
        const chapter = this.chapters.find(c => c.id === chapterId);
        if (!chapter) return;

        count = Math.max(0, Math.min(parseInt(count) || 0, chapter.totalQuestions));
        this.selectionConfig[chapterId] = count;

        // Sync range and number inputs
        const rangeInput = document.getElementById(`range-${chapterId}`);
        const numberInput = document.getElementById(`number-${chapterId}`);
        const checkbox = document.querySelector(`[data-chapter-id="${chapterId}"] input[type="checkbox"]`);

        if (rangeInput) rangeInput.value = count;
        if (numberInput) numberInput.value = count;
        if (checkbox) checkbox.checked = count > 0;

        // Update chapter content visibility
        const contentElement = document.querySelector(`[data-chapter-id="${chapterId}"] .chapter-content`);
        if (contentElement) {
            if (count > 0) {
                contentElement.classList.add('active');
            } else {
                contentElement.classList.remove('active');
            }
        }

        this.updateSelectionSummary();
        this.updateGenerateButton();
    }

    /**
     * Select all chapters with default question counts
     */
    selectAllChapters() {
        this.chapters.forEach(chapter => {
            const defaultCount = Math.min(5, chapter.totalQuestions);
            this.selectionConfig[chapter.id] = defaultCount;
        });
        
        this.renderChaptersList();
        this.updateSelectionSummary();
        this.updateGenerateButton();
        
        showNotification('All chapters selected', 'success');
    }

    /**
     * Clear all chapter selections
     */
    clearAllSelections() {
        this.selectionConfig = {};
        this.renderChaptersList();
        this.updateSelectionSummary();
        this.updateGenerateButton();
        
        showNotification('All selections cleared', 'info');
    }

    /**
     * Update the selection summary display
     */
    updateSelectionSummary() {
        const totalQuestions = this.chapters.reduce((sum, chapter) => sum + chapter.totalQuestions, 0);
        const selectedQuestions = Object.values(this.selectionConfig).reduce((sum, count) => sum + count, 0);
        const selectedChapters = Object.values(this.selectionConfig).filter(count => count > 0).length;

        document.getElementById('total-questions').textContent = totalQuestions;
        document.getElementById('selected-questions').textContent = selectedQuestions;

        // Update summary stats
        const summaryStats = document.getElementById('summary-stats');
        if (summaryStats) {
            summaryStats.innerHTML = `
                <div class="stat-item">
                    <span class="stat-label">Total Questions:</span>
                    <span class="stat-value">${totalQuestions}</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Selected:</span>
                    <span class="stat-value">${selectedQuestions}</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Chapters:</span>
                    <span class="stat-value">${selectedChapters} / ${this.chapters.length}</span>
                </div>
                <div class="stat-item">
                    <span class="stat-label">Estimated Time:</span>
                    <span class="stat-value">${Math.ceil(selectedQuestions * 1.5)} min</span>
                </div>
            `;
        }
    }

    /**
     * Update the generate paper button state
     */
    updateGenerateButton() {
        const btn = document.getElementById('generate-paper-btn');
        const selectedCount = Object.values(this.selectionConfig).reduce((sum, count) => sum + count, 0);
        
        if (btn) {
            btn.disabled = selectedCount === 0;
        }
    }

    /**
     * Show questions for a specific chapter
     * @param {string} chapterId - Chapter ID
     */
    showChapterQuestions(chapterId) {
        const chapter = this.chapters.find(c => c.id === chapterId);
        if (!chapter) return;

        // Create modal to show questions
        const modal = document.createElement('div');
        modal.className = 'question-modal';
        modal.innerHTML = `
            <div class="modal-overlay" onclick="this.parentElement.remove()"></div>
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${chapter.name}</h3>
                    <button class="modal-close" onclick="this.closest('.question-modal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="questions-list">
                        ${chapter.questions.map((q, index) => `
                            <div class="question-item">
                                <div class="question-number">${index + 1}.</div>
                                <div class="question-content">
                                    <div class="question-text">${q.question}</div>
                                    <div class="question-options">
                                        ${q.options.map(option => `<div class="option">${option}</div>`).join('')}
                                    </div>
                                    ${q.correctAnswer ? `<div class="correct-answer"><strong>Answer:</strong> ${q.correctAnswer}</div>` : ''}
                                    ${q.explanation ? `<div class="explanation"><strong>Explanation:</strong> ${q.explanation}</div>` : ''}
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
    }

    /**
     * Preview selected questions
     */
    previewQuestions() {
        const selectedQuestions = this.getSelectedQuestions();
        
        if (selectedQuestions.length === 0) {
            showNotification('No questions selected', 'warning');
            return;
        }

        // Create preview modal
        const modal = document.createElement('div');
        modal.className = 'question-modal';
        modal.innerHTML = `
            <div class="modal-overlay" onclick="this.parentElement.remove()"></div>
            <div class="modal-content large">
                <div class="modal-header">
                    <h3>Selected Questions Preview</h3>
                    <button class="modal-close" onclick="this.closest('.question-modal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="preview-summary">
                        <p><strong>Total Questions:</strong> ${selectedQuestions.length}</p>
                        <p><strong>Estimated Time:</strong> ${Math.ceil(selectedQuestions.length * 1.5)} minutes</p>
                    </div>
                    <div class="questions-list">
                        ${selectedQuestions.map((q, index) => `
                            <div class="question-item">
                                <div class="question-number">${index + 1}.</div>
                                <div class="question-content">
                                    <div class="question-text">${q.question}</div>
                                    <div class="question-options">
                                        ${q.options.map(option => `<div class="option">${option}</div>`).join('')}
                                    </div>
                                    <div class="question-meta">
                                        <span class="chapter-tag">Chapter: ${q.chapterName}</span>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
    }

    /**
     * Get selected questions based on current configuration
     * @returns {Array} Array of selected questions
     */
    getSelectedQuestions() {
        const selectedQuestions = [];

        this.chapters.forEach(chapter => {
            const count = this.selectionConfig[chapter.id] || 0;
            if (count > 0) {
                // Randomly select questions from this chapter
                const shuffledQuestions = shuffleArray(chapter.questions);
                const selectedFromChapter = shuffledQuestions.slice(0, count);
                
                // Add chapter name to each question
                selectedFromChapter.forEach(q => {
                    q.chapterName = chapter.name;
                });
                
                selectedQuestions.push(...selectedFromChapter);
            }
        });

        return shuffleArray(selectedQuestions);
    }

    /**
     * Generate paper and move to next step
     */
    generatePaper() {
        const selectedQuestions = this.getSelectedQuestions();
        
        if (selectedQuestions.length === 0) {
            showNotification('Please select at least one question', 'warning');
            return;
        }

        // Save selected questions
        this.selectedQuestions = selectedQuestions;
        saveToStorage('questionRandomizer_selectedQuestions', selectedQuestions);

        // Move to generation step
        this.moveToGenerationStep();
    }

    /**
     * Move to the paper generation step
     */
    moveToGenerationStep() {
        // Hide selection panel
        document.getElementById('selection-panel').classList.remove('active');
        
        // Show generation panel
        document.getElementById('generation-panel').classList.add('active');
        
        // Initialize paper generator
        if (window.paperGenerator) {
            paperGenerator.loadQuestions(this.selectedQuestions);
        }
    }

    /**
     * Go back to upload step
     */
    backToUpload() {
        // Hide selection panel
        document.getElementById('selection-panel').classList.remove('active');
        
        // Show upload panel
        document.getElementById('upload-panel').classList.add('active');
    }

    /**
     * Get current selection configuration
     * @returns {Object} Selection configuration
     */
    getSelectionConfig() {
        return this.selectionConfig;
    }

    /**
     * Set selection configuration
     * @param {Object} config - Selection configuration
     */
    setSelectionConfig(config) {
        this.selectionConfig = config || {};
        this.updateSelectionSummary();
        this.updateGenerateButton();
    }
}

// Initialize question manager when DOM is loaded
let questionManager;
document.addEventListener('DOMContentLoaded', () => {
    questionManager = new QuestionManager();
});


// File Handler Module for Question Randomizer Tool

class FileHandler {
    constructor() {
        this.uploadedFiles = [];
        this.processedChapters = [];
        this.initializeEventListeners();
    }

    /**
     * Initialize event listeners for file handling
     */
    initializeEventListeners() {
        const uploadArea = document.getElementById('upload-area');
        const fileInput = document.getElementById('file-input');
        const browseBtn = document.getElementById('browse-btn');

        // File input change event
        fileInput.addEventListener('change', (e) => {
            this.handleFiles(e.target.files);
        });

        // Browse button click
        browseBtn.addEventListener('click', () => {
            fileInput.click();
        });

        // Drag and drop events
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            this.handleFiles(e.dataTransfer.files);
        });

        // Click to upload
        uploadArea.addEventListener('click', () => {
            fileInput.click();
        });
    }

    /**
     * Handle uploaded files
     * @param {FileList} files - Uploaded files
     */
    async handleFiles(files) {
        const validFiles = Array.from(files).filter(file => {
            if (!isValidWordFile(file)) {
                showNotification(`${file.name} is not a valid Word document`, 'error');
                return false;
            }
            if (file.size > 10 * 1024 * 1024) { // 10MB limit
                showNotification(`${file.name} is too large (max 10MB)`, 'error');
                return false;
            }
            return true;
        });

        if (validFiles.length === 0) {
            return;
        }

        // Add files to uploaded list
        validFiles.forEach(file => {
            const fileData = {
                id: generateId(),
                file: file,
                name: file.name,
                size: file.size,
                status: 'pending',
                questions: [],
                chapterName: ''
            };
            this.uploadedFiles.push(fileData);
        });

        this.updateUploadedFilesList();
        this.enableProcessButton();
    }

    /**
     * Update the uploaded files display
     */
    updateUploadedFilesList() {
        const container = document.getElementById('uploaded-files');
        
        if (this.uploadedFiles.length === 0) {
            container.innerHTML = '';
            return;
        }

        container.innerHTML = `
            <h4>Uploaded Files (${this.uploadedFiles.length})</h4>
            <div class="files-list">
                ${this.uploadedFiles.map(fileData => `
                    <div class="file-item" data-file-id="${fileData.id}">
                        <div class="file-icon">
                            <i class="fas fa-file-word"></i>
                        </div>
                        <div class="file-info">
                            <div class="file-name">${fileData.name}</div>
                            <div class="file-size">${formatFileSize(fileData.size)}</div>
                        </div>
                        <div class="file-status ${fileData.status}">
                            ${this.getStatusText(fileData.status)}
                        </div>
                        <button class="btn-remove" onclick="fileHandler.removeFile('${fileData.id}')" title="Remove file">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                `).join('')}
            </div>
        `;
    }

    /**
     * Get status text for file
     * @param {string} status - File status
     * @returns {string} Status text
     */
    getStatusText(status) {
        const statusMap = {
            pending: 'Pending',
            processing: 'Processing...',
            completed: 'Completed',
            error: 'Error'
        };
        return statusMap[status] || 'Unknown';
    }

    /**
     * Remove file from upload list
     * @param {string} fileId - File ID to remove
     */
    removeFile(fileId) {
        this.uploadedFiles = this.uploadedFiles.filter(f => f.id !== fileId);
        this.updateUploadedFilesList();
        
        if (this.uploadedFiles.length === 0) {
            this.disableProcessButton();
        }
    }

    /**
     * Enable the process files button
     */
    enableProcessButton() {
        const btn = document.getElementById('process-files-btn');
        btn.disabled = false;
    }

    /**
     * Disable the process files button
     */
    disableProcessButton() {
        const btn = document.getElementById('process-files-btn');
        btn.disabled = true;
    }

    /**
     * Process all uploaded files
     */
    async processFiles() {
        if (this.uploadedFiles.length === 0) {
            showNotification('No files to process', 'warning');
            return;
        }

        showLoading('Processing uploaded files...');
        this.processedChapters = [];

        try {
            for (const fileData of this.uploadedFiles) {
                await this.processFile(fileData);
            }

            // Save processed chapters to storage
            saveToStorage('questionRandomizer_chapters', this.processedChapters);

            hideLoading();
            showNotification(`Successfully processed ${this.processedChapters.length} chapters`, 'success');

            // Move to next step
            this.moveToSelectionStep();

        } catch (error) {
            hideLoading();
            console.error('Error processing files:', error);
            showNotification('Error processing files. Please try again.', 'error');
        }
    }

    /**
     * Process a single file
     * @param {Object} fileData - File data object
     */
    async processFile(fileData) {
        try {
            fileData.status = 'processing';
            this.updateUploadedFilesList();

            const content = await this.extractTextFromFile(fileData.file);
            const questions = this.parseQuestionsFromContent(content);
            
            if (questions.length === 0) {
                throw new Error('No valid questions found in file');
            }

            const chapterName = extractChapterName(fileData.name, content);
            
            const chapter = {
                id: generateId(),
                name: chapterName,
                fileName: fileData.name,
                questions: questions,
                totalQuestions: questions.length
            };

            this.processedChapters.push(chapter);
            
            fileData.status = 'completed';
            fileData.questions = questions;
            fileData.chapterName = chapterName;

        } catch (error) {
            console.error(`Error processing file ${fileData.name}:`, error);
            fileData.status = 'error';
            showNotification(`Error processing ${fileData.name}: ${error.message}`, 'error');
        }

        this.updateUploadedFilesList();
    }

    /**
     * Extract text content from Word file
     * @param {File} file - Word file
     * @returns {Promise<string>} Extracted text
     */
    async extractTextFromFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = async (e) => {
                try {
                    if (typeof mammoth !== 'undefined') {
                        // Use mammoth.js for .docx files
                        const result = await mammoth.extractRawText({
                            arrayBuffer: e.target.result
                        });
                        resolve(result.value);
                    } else {
                        // Fallback for when mammoth.js is not available
                        // This is a very basic text extraction
                        const text = new TextDecoder().decode(e.target.result);
                        resolve(this.extractTextFallback(text));
                    }
                } catch (error) {
                    reject(error);
                }
            };
            
            reader.onerror = () => reject(new Error('Failed to read file'));
            reader.readAsArrayBuffer(file);
        });
    }

    /**
     * Fallback text extraction method
     * @param {string} rawText - Raw file content
     * @returns {string} Extracted text
     */
    extractTextFallback(rawText) {
        // Very basic text extraction - in a real implementation,
        // you'd want a more sophisticated approach
        return rawText
            .replace(/[^\x20-\x7E\n\r]/g, ' ') // Remove non-printable characters
            .replace(/\s+/g, ' ') // Normalize whitespace
            .trim();
    }

    /**
     * Parse questions from extracted text content
     * @param {string} content - Text content
     * @returns {Array} Array of question objects
     */
    parseQuestionsFromContent(content) {
        const questions = [];
        
        // Split content into potential question blocks
        // This is a simplified parsing logic
        const blocks = content.split(/\n\s*\n/).filter(block => block.trim());
        
        for (const block of blocks) {
            const question = parseQuestion(block);
            if (question) {
                questions.push(question);
            }
        }

        // If no questions found with the above method, try alternative parsing
        if (questions.length === 0) {
            const alternativeQuestions = this.parseQuestionsAlternative(content);
            questions.push(...alternativeQuestions);
        }

        return questions;
    }

    /**
     * Alternative question parsing method
     * @param {string} content - Text content
     * @returns {Array} Array of question objects
     */
    parseQuestionsAlternative(content) {
        const questions = [];
        const lines = content.split('\n').map(line => line.trim()).filter(line => line);
        
        let currentQuestion = null;
        let currentOptions = [];
        let currentAnswer = '';
        let currentExplanation = '';
        
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            
            // Check if this line looks like a question (ends with ?)
            if (line.endsWith('?') && line.length > 10) {
                // Save previous question if exists
                if (currentQuestion && currentOptions.length >= 2) {
                    questions.push({
                        id: generateId(),
                        question: currentQuestion,
                        options: [...currentOptions],
                        correctAnswer: currentAnswer,
                        explanation: currentExplanation
                    });
                }
                
                // Start new question
                currentQuestion = line;
                currentOptions = [];
                currentAnswer = '';
                currentExplanation = '';
            }
            // Check if this line looks like an option
            else if (line.match(/^[a-d][\)\.]\s*/i)) {
                currentOptions.push(line);
            }
            // Check if this line contains answer
            else if (line.toLowerCase().includes('answer') || line.toLowerCase().includes('correct')) {
                currentAnswer = line;
            }
            // Check if this line contains explanation
            else if (line.toLowerCase().includes('explanation') || line.toLowerCase().includes('explain')) {
                currentExplanation = line;
            }
        }
        
        // Don't forget the last question
        if (currentQuestion && currentOptions.length >= 2) {
            questions.push({
                id: generateId(),
                question: currentQuestion,
                options: [...currentOptions],
                correctAnswer: currentAnswer,
                explanation: currentExplanation
            });
        }
        
        return questions;
    }

    /**
     * Move to the question selection step
     */
    moveToSelectionStep() {
        // Hide upload panel
        document.getElementById('upload-panel').classList.remove('active');
        
        // Show selection panel
        document.getElementById('selection-panel').classList.add('active');
        
        // Initialize question manager with processed chapters
        if (window.questionManager) {
            questionManager.loadChapters(this.processedChapters);
        }
    }

    /**
     * Get processed chapters
     * @returns {Array} Array of chapter objects
     */
    getProcessedChapters() {
        return this.processedChapters;
    }

    /**
     * Clear all uploaded files
     */
    clearFiles() {
        this.uploadedFiles = [];
        this.processedChapters = [];
        this.updateUploadedFilesList();
        this.disableProcessButton();
    }
}

// Initialize file handler when DOM is loaded
let fileHandler;
document.addEventListener('DOMContentLoaded', () => {
    fileHandler = new FileHandler();
});


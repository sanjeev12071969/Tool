// Paper Generator Module for Question Randomizer Tool

class PaperGenerator {
    constructor() {
        this.questions = [];
        this.paperConfig = {
            title: 'Sample Question Paper',
            duration: '3 Hours',
            maxMarks: 100,
            instructions: `1. Read all questions carefully.
2. Choose the correct answer from the given options.
3. Each question carries equal marks.
4. There is no negative marking.`
        };
        this.initializeEventListeners();
    }

    /**
     * Initialize event listeners for paper generation
     */
    initializeEventListeners() {
        // Back to selection button
        const backToSelectionBtn = document.getElementById('back-to-selection-btn');
        if (backToSelectionBtn) {
            backToSelectionBtn.addEventListener('click', () => {
                this.backToSelection();
            });
        }

        // Download buttons
        const downloadPaperBtn = document.getElementById('download-paper-btn');
        const downloadAnswersBtn = document.getElementById('download-answers-btn');

        if (downloadPaperBtn) {
            downloadPaperBtn.addEventListener('click', () => {
                this.downloadQuestionPaper();
            });
        }

        if (downloadAnswersBtn) {
            downloadAnswersBtn.addEventListener('click', () => {
                this.downloadAnswerKey();
            });
        }

        // Config input listeners
        this.initializeConfigListeners();
    }

    /**
     * Initialize configuration input listeners
     */
    initializeConfigListeners() {
        const inputs = ['paper-title', 'time-duration', 'max-marks', 'instructions'];
        
        inputs.forEach(inputId => {
            const element = document.getElementById(inputId);
            if (element) {
                element.addEventListener('input', debounce(() => {
                    this.updateConfig();
                    this.updatePreview();
                }, 300));
            }
        });
    }

    /**
     * Load questions for paper generation
     * @param {Array} questions - Array of question objects
     */
    loadQuestions(questions) {
        this.questions = questions || [];
        
        // Try to load from storage if no questions provided
        if (this.questions.length === 0) {
            const storedQuestions = loadFromStorage('questionRandomizer_selectedQuestions');
            if (storedQuestions) {
                this.questions = storedQuestions;
            }
        }

        // Load saved config
        const savedConfig = loadFromStorage('questionRandomizer_paperConfig');
        if (savedConfig) {
            this.paperConfig = { ...this.paperConfig, ...savedConfig };
            this.populateConfigForm();
        }

        this.updatePreview();
        this.updateDownloadButtons();
    }

    /**
     * Populate configuration form with saved values
     */
    populateConfigForm() {
        document.getElementById('paper-title').value = this.paperConfig.title;
        document.getElementById('time-duration').value = this.paperConfig.duration;
        document.getElementById('max-marks').value = this.paperConfig.maxMarks;
        document.getElementById('instructions').value = this.paperConfig.instructions;
    }

    /**
     * Update configuration from form inputs
     */
    updateConfig() {
        this.paperConfig = {
            title: document.getElementById('paper-title').value || 'Sample Question Paper',
            duration: document.getElementById('time-duration').value || '3 Hours',
            maxMarks: parseInt(document.getElementById('max-marks').value) || 100,
            instructions: document.getElementById('instructions').value || this.paperConfig.instructions
        };

        // Save config to storage
        saveToStorage('questionRandomizer_paperConfig', this.paperConfig);
    }

    /**
     * Update the preview display
     */
    updatePreview() {
        const previewContainer = document.getElementById('preview-content');
        
        if (this.questions.length === 0) {
            previewContainer.innerHTML = `
                <div class="preview-empty">
                    <i class="fas fa-file-alt"></i>
                    <h4>No Questions Selected</h4>
                    <p>Please go back and select questions to generate a paper.</p>
                </div>
            `;
            return;
        }

        const marksPerQuestion = Math.round(this.paperConfig.maxMarks / this.questions.length);
        
        previewContainer.innerHTML = `
            <div class="paper-preview">
                <div class="paper-header">
                    <h3>${this.paperConfig.title}</h3>
                    <div class="paper-meta">
                        <div class="meta-item">
                            <strong>Time:</strong> ${this.paperConfig.duration}
                        </div>
                        <div class="meta-item">
                            <strong>Maximum Marks:</strong> ${this.paperConfig.maxMarks}
                        </div>
                        <div class="meta-item">
                            <strong>Questions:</strong> ${this.questions.length}
                        </div>
                    </div>
                </div>
                
                <div class="paper-instructions">
                    <h4>Instructions:</h4>
                    <div class="instructions-text">
                        ${this.paperConfig.instructions.split('\n').map(line => 
                            line.trim() ? `<p>${line}</p>` : ''
                        ).join('')}
                    </div>
                </div>
                
                <div class="paper-questions">
                    <h4>Questions:</h4>
                    <div class="questions-preview">
                        ${this.questions.slice(0, 3).map((question, index) => `
                            <div class="question-preview-item">
                                <div class="question-number">${index + 1}.</div>
                                <div class="question-text">${question.question}</div>
                                <div class="question-marks">[${marksPerQuestion} marks]</div>
                            </div>
                        `).join('')}
                        ${this.questions.length > 3 ? `
                            <div class="more-questions">
                                <i class="fas fa-ellipsis-h"></i>
                                <span>and ${this.questions.length - 3} more questions...</span>
                            </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * Update download buttons state
     */
    updateDownloadButtons() {
        const paperBtn = document.getElementById('download-paper-btn');
        const answersBtn = document.getElementById('download-answers-btn');
        
        const hasQuestions = this.questions.length > 0;
        
        if (paperBtn) paperBtn.disabled = !hasQuestions;
        if (answersBtn) answersBtn.disabled = !hasQuestions;
    }

    /**
     * Generate and download question paper
     */
    downloadQuestionPaper() {
        if (this.questions.length === 0) {
            showNotification('No questions available to generate paper', 'warning');
            return;
        }

        const validation = validatePaperConfig(this.paperConfig);
        if (!validation.isValid) {
            showNotification(`Please fix the following issues:\n${validation.errors.join('\n')}`, 'error');
            return;
        }

        showLoading('Generating question paper...');

        try {
            const paperContent = this.generateQuestionPaperContent();
            const filename = `${this.paperConfig.title.replace(/[^a-zA-Z0-9]/g, '_')}_Questions.docx`;
            
            // For now, we'll generate a simple text version
            // In a real implementation, you'd use a library like docx to create proper Word documents
            this.downloadAsWordDocument(paperContent, filename, false);
            
            hideLoading();
            showNotification('Question paper downloaded successfully!', 'success');
            
        } catch (error) {
            hideLoading();
            console.error('Error generating question paper:', error);
            showNotification('Error generating question paper. Please try again.', 'error');
        }
    }

    /**
     * Generate and download answer key
     */
    downloadAnswerKey() {
        if (this.questions.length === 0) {
            showNotification('No questions available to generate answer key', 'warning');
            return;
        }

        showLoading('Generating answer key...');

        try {
            const answerContent = this.generateAnswerKeyContent();
            const filename = `${this.paperConfig.title.replace(/[^a-zA-Z0-9]/g, '_')}_Answers.docx`;
            
            this.downloadAsWordDocument(answerContent, filename, true);
            
            hideLoading();
            showNotification('Answer key downloaded successfully!', 'success');
            
        } catch (error) {
            hideLoading();
            console.error('Error generating answer key:', error);
            showNotification('Error generating answer key. Please try again.', 'error');
        }
    }

    /**
     * Generate question paper content
     * @returns {string} Question paper content
     */
    generateQuestionPaperContent() {
        const marksPerQuestion = Math.round(this.paperConfig.maxMarks / this.questions.length);
        
        let content = `${this.paperConfig.title}\n\n`;
        content += `Time: ${this.paperConfig.duration}\n`;
        content += `Maximum Marks: ${this.paperConfig.maxMarks}\n`;
        content += `Total Questions: ${this.questions.length}\n\n`;
        
        content += `INSTRUCTIONS:\n`;
        content += `${this.paperConfig.instructions}\n\n`;
        content += `${'='.repeat(60)}\n\n`;
        
        this.questions.forEach((question, index) => {
            content += `${index + 1}. ${question.question}\n`;
            content += `   [${marksPerQuestion} marks]\n\n`;
            
            question.options.forEach((option, optIndex) => {
                content += `   ${option}\n`;
            });
            
            content += `\n`;
        });
        
        content += `\n${'='.repeat(60)}\n`;
        content += `END OF QUESTION PAPER\n`;
        content += `Generated on: ${formatDate()}\n`;
        
        return content;
    }

    /**
     * Generate answer key content
     * @returns {string} Answer key content
     */
    generateAnswerKeyContent() {
        const marksPerQuestion = Math.round(this.paperConfig.maxMarks / this.questions.length);
        
        let content = `${this.paperConfig.title} - ANSWER KEY\n\n`;
        content += `Time: ${this.paperConfig.duration}\n`;
        content += `Maximum Marks: ${this.paperConfig.maxMarks}\n`;
        content += `Total Questions: ${this.questions.length}\n\n`;
        content += `${'='.repeat(60)}\n\n`;
        
        // Quick answer reference
        content += `QUICK REFERENCE:\n`;
        this.questions.forEach((question, index) => {
            const answerLetter = this.extractAnswerLetter(question.correctAnswer);
            content += `${index + 1}. ${answerLetter || 'N/A'}\n`;
        });
        content += `\n${'='.repeat(60)}\n\n`;
        
        // Detailed answers
        content += `DETAILED ANSWERS:\n\n`;
        this.questions.forEach((question, index) => {
            content += `${index + 1}. ${question.question}\n`;
            content += `   [${marksPerQuestion} marks]\n\n`;
            
            question.options.forEach((option, optIndex) => {
                const isCorrect = this.isCorrectOption(option, question.correctAnswer);
                content += `   ${option}${isCorrect ? ' ✓ CORRECT' : ''}\n`;
            });
            
            if (question.correctAnswer) {
                content += `\n   ANSWER: ${question.correctAnswer}\n`;
            }
            
            if (question.explanation) {
                content += `   EXPLANATION: ${question.explanation}\n`;
            }
            
            if (question.chapterName) {
                content += `   CHAPTER: ${question.chapterName}\n`;
            }
            
            content += `\n${'='.repeat(40)}\n\n`;
        });
        
        content += `Generated on: ${formatDate()}\n`;
        
        return content;
    }

    /**
     * Extract answer letter from answer text
     * @param {string} answer - Answer text
     * @returns {string} Answer letter
     */
    extractAnswerLetter(answer) {
        if (!answer) return '';
        
        const match = answer.match(/[a-d]/i);
        return match ? match[0].toUpperCase() : '';
    }

    /**
     * Check if an option is the correct answer
     * @param {string} option - Option text
     * @param {string} correctAnswer - Correct answer text
     * @returns {boolean} True if correct
     */
    isCorrectOption(option, correctAnswer) {
        if (!correctAnswer) return false;
        
        const optionLetter = option.match(/^([a-d])/i);
        const answerLetter = this.extractAnswerLetter(correctAnswer);
        
        if (optionLetter && answerLetter) {
            return optionLetter[1].toLowerCase() === answerLetter.toLowerCase();
        }
        
        return option.toLowerCase().includes(correctAnswer.toLowerCase());
    }

    /**
     * Download content as Word document
     * @param {string} content - Document content
     * @param {string} filename - File name
     * @param {boolean} isAnswerKey - Whether this is an answer key
     */
    downloadAsWordDocument(content, filename, isAnswerKey = false) {
        // For now, we'll create a simple HTML document that can be opened in Word
        // In a production environment, you'd want to use a proper Word document library
        
        const htmlContent = this.convertToWordHTML(content, isAnswerKey);
        
        const blob = new Blob([htmlContent], {
            type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        });
        
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    /**
     * Convert plain text content to Word-compatible HTML
     * @param {string} content - Plain text content
     * @param {boolean} isAnswerKey - Whether this is an answer key
     * @returns {string} HTML content
     */
    convertToWordHTML(content, isAnswerKey = false) {
        const lines = content.split('\n');
        let html = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>${isAnswerKey ? 'Answer Key' : 'Question Paper'}</title>
    <style>
        body {
            font-family: 'Times New Roman', serif;
            font-size: 12pt;
            line-height: 1.5;
            margin: 1in;
            color: #000;
        }
        h1 {
            text-align: center;
            font-size: 16pt;
            font-weight: bold;
            margin-bottom: 20pt;
        }
        .header-info {
            margin-bottom: 20pt;
            border-bottom: 1pt solid #000;
            padding-bottom: 10pt;
        }
        .instructions {
            margin: 20pt 0;
            padding: 10pt;
            border: 1pt solid #000;
        }
        .question {
            margin: 15pt 0;
            page-break-inside: avoid;
        }
        .question-number {
            font-weight: bold;
        }
        .options {
            margin-left: 20pt;
            margin-top: 5pt;
        }
        .correct-answer {
            color: #008000;
            font-weight: bold;
        }
        .explanation {
            margin-top: 5pt;
            font-style: italic;
            color: #666;
        }
        .separator {
            border-top: 1pt solid #ccc;
            margin: 20pt 0;
        }
        @page {
            margin: 1in;
        }
    </style>
</head>
<body>
`;

        let inInstructions = false;
        let inQuestion = false;
        
        lines.forEach(line => {
            const trimmedLine = line.trim();
            
            if (trimmedLine.includes('INSTRUCTIONS:')) {
                html += '<div class="instructions"><h3>INSTRUCTIONS:</h3>';
                inInstructions = true;
            } else if (trimmedLine.startsWith('='.repeat(10))) {
                if (inInstructions) {
                    html += '</div>';
                    inInstructions = false;
                } else {
                    html += '<div class="separator"></div>';
                }
            } else if (trimmedLine.match(/^\d+\./)) {
                if (inQuestion) html += '</div>';
                html += '<div class="question">';
                html += `<div class="question-number">${trimmedLine}</div>`;
                inQuestion = true;
            } else if (trimmedLine.match(/^[a-d][\)\.]/i)) {
                if (!html.includes('<div class="options">')) {
                    html += '<div class="options">';
                }
                const isCorrect = isAnswerKey && trimmedLine.includes('✓ CORRECT');
                html += `<div class="${isCorrect ? 'correct-answer' : ''}">${trimmedLine}</div>`;
            } else if (trimmedLine.startsWith('ANSWER:')) {
                html += `<div class="correct-answer">${trimmedLine}</div>`;
            } else if (trimmedLine.startsWith('EXPLANATION:')) {
                html += `<div class="explanation">${trimmedLine}</div>`;
            } else if (trimmedLine.length > 0) {
                if (trimmedLine.includes(this.paperConfig.title) && !html.includes('<h1>')) {
                    html += `<h1>${trimmedLine}</h1>`;
                } else if (trimmedLine.includes('Time:') || trimmedLine.includes('Maximum Marks:') || trimmedLine.includes('Total Questions:')) {
                    if (!html.includes('<div class="header-info">')) {
                        html += '<div class="header-info">';
                    }
                    html += `<p><strong>${trimmedLine}</strong></p>`;
                } else {
                    html += `<p>${trimmedLine}</p>`;
                }
            }
        });
        
        if (inQuestion) html += '</div>';
        if (html.includes('<div class="header-info">') && !html.includes('</div>')) {
            html += '</div>';
        }
        
        html += `
</body>
</html>
`;
        
        return html;
    }

    /**
     * Go back to question selection
     */
    backToSelection() {
        // Hide generation panel
        document.getElementById('generation-panel').classList.remove('active');
        
        // Show selection panel
        document.getElementById('selection-panel').classList.add('active');
    }

    /**
     * Get current paper configuration
     * @returns {Object} Paper configuration
     */
    getPaperConfig() {
        return this.paperConfig;
    }

    /**
     * Set paper configuration
     * @param {Object} config - Paper configuration
     */
    setPaperConfig(config) {
        this.paperConfig = { ...this.paperConfig, ...config };
        this.populateConfigForm();
        this.updatePreview();
        saveToStorage('questionRandomizer_paperConfig', this.paperConfig);
    }

    /**
     * Get loaded questions
     * @returns {Array} Array of questions
     */
    getQuestions() {
        return this.questions;
    }
}

// Initialize paper generator when DOM is loaded
let paperGenerator;
document.addEventListener('DOMContentLoaded', () => {
    paperGenerator = new PaperGenerator();
});


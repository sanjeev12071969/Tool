// Utility Functions for Question Randomizer Tool

/**
 * Generate a unique ID
 * @returns {string} Unique identifier
 */
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

/**
 * Format file size in human readable format
 * @param {number} bytes - File size in bytes
 * @returns {string} Formatted file size
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Shuffle array using Fisher-Yates algorithm
 * @param {Array} array - Array to shuffle
 * @returns {Array} Shuffled array
 */
function shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

/**
 * Debounce function to limit function calls
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @returns {Function} Debounced function
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Show loading overlay
 * @param {string} message - Loading message
 */
function showLoading(message = 'Processing...') {
    const overlay = document.getElementById('loading-overlay');
    const messageElement = overlay.querySelector('p');
    messageElement.textContent = message;
    overlay.classList.add('active');
}

/**
 * Hide loading overlay
 */
function hideLoading() {
    const overlay = document.getElementById('loading-overlay');
    overlay.classList.remove('active');
}

/**
 * Show notification message
 * @param {string} message - Notification message
 * @param {string} type - Notification type (success, error, warning, info)
 */
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${getNotificationIcon(type)}"></i>
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

/**
 * Get notification icon based on type
 * @param {string} type - Notification type
 * @returns {string} Icon class
 */
function getNotificationIcon(type) {
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    return icons[type] || 'info-circle';
}

/**
 * Validate file type
 * @param {File} file - File to validate
 * @returns {boolean} True if valid
 */
function isValidWordFile(file) {
    const validTypes = [
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/msword'
    ];
    const validExtensions = ['.docx', '.doc'];
    
    const hasValidType = validTypes.includes(file.type);
    const hasValidExtension = validExtensions.some(ext => 
        file.name.toLowerCase().endsWith(ext)
    );
    
    return hasValidType || hasValidExtension;
}

/**
 * Parse question text and extract components
 * @param {string} text - Raw question text
 * @returns {Object} Parsed question object
 */
function parseQuestion(text) {
    // Basic question parsing logic
    // This is a simplified version - in a real implementation,
    // you'd want more sophisticated parsing
    
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length < 2) return null;
    
    const question = lines[0].trim();
    const options = [];
    let correctAnswer = '';
    let explanation = '';
    
    let currentSection = 'options';
    
    for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        
        if (line.toLowerCase().startsWith('answer:') || 
            line.toLowerCase().startsWith('correct:')) {
            currentSection = 'answer';
            correctAnswer = line.split(':')[1]?.trim() || '';
        } else if (line.toLowerCase().startsWith('explanation:') || 
                   line.toLowerCase().startsWith('explain:')) {
            currentSection = 'explanation';
            explanation = line.split(':')[1]?.trim() || '';
        } else if (currentSection === 'options' && 
                   (line.match(/^[a-d]\)/i) || line.match(/^[a-d]\./i))) {
            options.push(line);
        } else if (currentSection === 'explanation') {
            explanation += ' ' + line;
        }
    }
    
    if (!question || options.length < 2) return null;
    
    return {
        id: generateId(),
        question: question,
        options: options,
        correctAnswer: correctAnswer,
        explanation: explanation.trim()
    };
}

/**
 * Extract chapter name from filename or content
 * @param {string} filename - File name
 * @param {string} content - File content
 * @returns {string} Chapter name
 */
function extractChapterName(filename, content = '') {
    // Remove file extension
    let chapterName = filename.replace(/\.(docx?|txt)$/i, '');
    
    // Clean up common prefixes/suffixes
    chapterName = chapterName
        .replace(/^(chapter|ch|unit)\s*\d*\s*[-_]?\s*/i, '')
        .replace(/\s*[-_]\s*(questions?|mcq|quiz)$/i, '')
        .trim();
    
    // If still empty or too short, try to extract from content
    if (chapterName.length < 3 && content) {
        const firstLine = content.split('\n')[0]?.trim();
        if (firstLine && firstLine.length > 3 && firstLine.length < 100) {
            chapterName = firstLine;
        }
    }
    
    // Fallback to filename if all else fails
    if (chapterName.length < 3) {
        chapterName = filename.replace(/\.(docx?|txt)$/i, '');
    }
    
    return chapterName;
}

/**
 * Save data to localStorage
 * @param {string} key - Storage key
 * @param {*} data - Data to save
 */
function saveToStorage(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
        console.error('Failed to save to localStorage:', error);
        showNotification('Failed to save data locally', 'error');
    }
}

/**
 * Load data from localStorage
 * @param {string} key - Storage key
 * @returns {*} Loaded data or null
 */
function loadFromStorage(key) {
    try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    } catch (error) {
        console.error('Failed to load from localStorage:', error);
        return null;
    }
}

/**
 * Clear all application data
 */
function clearAllData() {
    try {
        localStorage.removeItem('questionRandomizer_chapters');
        localStorage.removeItem('questionRandomizer_settings');
        showNotification('All data cleared successfully', 'success');
    } catch (error) {
        console.error('Failed to clear data:', error);
        showNotification('Failed to clear data', 'error');
    }
}

/**
 * Download text as file
 * @param {string} content - File content
 * @param {string} filename - File name
 * @param {string} mimeType - MIME type
 */
function downloadTextFile(content, filename, mimeType = 'text/plain') {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    URL.revokeObjectURL(url);
}

/**
 * Format date for display
 * @param {Date} date - Date to format
 * @returns {string} Formatted date string
 */
function formatDate(date = new Date()) {
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

/**
 * Validate question paper configuration
 * @param {Object} config - Configuration object
 * @returns {Object} Validation result
 */
function validatePaperConfig(config) {
    const errors = [];
    
    if (!config.title || config.title.trim().length < 3) {
        errors.push('Paper title must be at least 3 characters long');
    }
    
    if (!config.duration || config.duration.trim().length < 1) {
        errors.push('Time duration is required');
    }
    
    if (!config.maxMarks || config.maxMarks < 1) {
        errors.push('Maximum marks must be greater than 0');
    }
    
    if (!config.instructions || config.instructions.trim().length < 10) {
        errors.push('Instructions must be at least 10 characters long');
    }
    
    return {
        isValid: errors.length === 0,
        errors: errors
    };
}

// Add notification styles to the page
const notificationStyles = `
<style>
.notification {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 10000;
    max-width: 400px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    animation: slideInRight 0.3s ease-out;
}

.notification-content {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 16px;
}

.notification-success {
    border-left: 4px solid #10b981;
}

.notification-error {
    border-left: 4px solid #ef4444;
}

.notification-warning {
    border-left: 4px solid #f59e0b;
}

.notification-info {
    border-left: 4px solid #3b82f6;
}

.notification-close {
    background: none;
    border: none;
    cursor: pointer;
    color: #6b7280;
    margin-left: auto;
}

.notification-close:hover {
    color: #374151;
}

@keyframes slideInRight {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}
</style>
`;

// Add styles to head
document.head.insertAdjacentHTML('beforeend', notificationStyles);


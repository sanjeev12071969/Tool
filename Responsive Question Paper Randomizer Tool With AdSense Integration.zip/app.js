// Main Application JavaScript for Question Randomizer Tool

class QuestionRandomizerApp {
    constructor() {
        this.currentStep = 'upload';
        this.isInitialized = false;
        this.init();
    }

    /**
     * Initialize the application
     */
    init() {
        if (this.isInitialized) return;
        
        this.initializeEventListeners();
        this.initializeNavigation();
        this.loadSavedData();
        this.initializeAdSense();
        
        this.isInitialized = true;
        console.log('Question Randomizer App initialized');
    }

    /**
     * Initialize global event listeners
     */
    initializeEventListeners() {
        // Navigation menu toggle
        const navToggle = document.querySelector('.nav-toggle');
        const navMenu = document.querySelector('.nav-menu');
        
        if (navToggle && navMenu) {
            navToggle.addEventListener('click', () => {
                navToggle.classList.toggle('active');
                navMenu.classList.toggle('active');
            });
        }

        // Smooth scrolling for navigation links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const targetId = link.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);
                
                if (targetElement) {
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
                
                // Close mobile menu
                if (navMenu) navMenu.classList.remove('active');
                if (navToggle) navToggle.classList.remove('active');
            });
        });

        // Hero section buttons
        const getStartedBtn = document.getElementById('get-started-btn');
        const learnMoreBtn = document.getElementById('learn-more-btn');

        if (getStartedBtn) {
            getStartedBtn.addEventListener('click', () => {
                this.scrollToApp();
            });
        }

        if (learnMoreBtn) {
            learnMoreBtn.addEventListener('click', () => {
                const howItWorksSection = document.getElementById('how-it-works');
                if (howItWorksSection) {
                    howItWorksSection.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        }

        // Process files button
        const processFilesBtn = document.getElementById('process-files-btn');
        if (processFilesBtn) {
            processFilesBtn.addEventListener('click', () => {
                if (window.fileHandler) {
                    fileHandler.processFiles();
                }
            });
        }

        // Window resize handler
        window.addEventListener('resize', debounce(() => {
            this.handleResize();
        }, 250));

        // Before unload warning
        window.addEventListener('beforeunload', (e) => {
            if (this.hasUnsavedChanges()) {
                e.preventDefault();
                e.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
                return e.returnValue;
            }
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            this.handleKeyboardShortcuts(e);
        });
    }

    /**
     * Initialize navigation and step management
     */
    initializeNavigation() {
        // Set up step navigation
        this.updateStepIndicators();
    }

    /**
     * Load saved data from localStorage
     */
    loadSavedData() {
        try {
            // Load saved chapters
            const savedChapters = loadFromStorage('questionRandomizer_chapters');
            if (savedChapters && savedChapters.length > 0) {
                console.log(`Loaded ${savedChapters.length} saved chapters`);
                
                // If we have saved data, we might want to skip to selection step
                const skipToSelection = confirm(
                    'Found previously uploaded chapters. Would you like to continue from where you left off?'
                );
                
                if (skipToSelection) {
                    this.goToStep('selection');
                    if (window.questionManager) {
                        questionManager.loadChapters(savedChapters);
                    }
                }
            }

            // Load saved paper config
            const savedConfig = loadFromStorage('questionRandomizer_paperConfig');
            if (savedConfig && window.paperGenerator) {
                paperGenerator.setPaperConfig(savedConfig);
            }

            // Load saved questions
            const savedQuestions = loadFromStorage('questionRandomizer_selectedQuestions');
            if (savedQuestions && savedQuestions.length > 0) {
                console.log(`Loaded ${savedQuestions.length} saved questions`);
            }

        } catch (error) {
            console.error('Error loading saved data:', error);
        }
    }

    /**
     * Initialize Google AdSense
     */
    initializeAdSense() {
        try {
            // Initialize AdSense ads
            if (typeof adsbygoogle !== 'undefined') {
                (adsbygoogle = window.adsbygoogle || []).push({});
            }
        } catch (error) {
            console.error('Error initializing AdSense:', error);
        }
    }

    /**
     * Scroll to the application interface
     */
    scrollToApp() {
        const appSection = document.getElementById('app-interface');
        if (appSection) {
            appSection.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }

    /**
     * Go to a specific step
     * @param {string} stepName - Step name (upload, selection, generation)
     */
    goToStep(stepName) {
        // Hide all panels
        document.querySelectorAll('.step-panel').forEach(panel => {
            panel.classList.remove('active');
        });

        // Show target panel
        const targetPanel = document.getElementById(`${stepName}-panel`);
        if (targetPanel) {
            targetPanel.classList.add('active');
            this.currentStep = stepName;
            this.updateStepIndicators();
        }
    }

    /**
     * Update step indicators
     */
    updateStepIndicators() {
        const steps = ['upload', 'selection', 'generation'];
        const currentIndex = steps.indexOf(this.currentStep);

        steps.forEach((step, index) => {
            const stepElement = document.querySelector(`#${step}-panel .step-number`);
            if (stepElement) {
                stepElement.classList.toggle('completed', index < currentIndex);
                stepElement.classList.toggle('active', index === currentIndex);
            }
        });
    }

    /**
     * Handle window resize
     */
    handleResize() {
        // Close mobile menu on resize
        const navMenu = document.querySelector('.nav-menu');
        const navToggle = document.querySelector('.nav-toggle');
        
        if (window.innerWidth > 991) {
            if (navMenu) navMenu.classList.remove('active');
            if (navToggle) navToggle.classList.remove('active');
        }

        // Update any responsive components
        this.updateResponsiveComponents();
    }

    /**
     * Update responsive components
     */
    updateResponsiveComponents() {
        // Update any components that need to respond to size changes
        // This could include charts, tables, or other dynamic content
    }

    /**
     * Handle keyboard shortcuts
     * @param {KeyboardEvent} e - Keyboard event
     */
    handleKeyboardShortcuts(e) {
        // Ctrl/Cmd + S to save current state
        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
            e.preventDefault();
            this.saveCurrentState();
            showNotification('Current state saved', 'success');
        }

        // Escape to close modals
        if (e.key === 'Escape') {
            this.closeAllModals();
        }

        // Ctrl/Cmd + Z to clear all data (with confirmation)
        if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
            e.preventDefault();
            this.confirmClearAllData();
        }
    }

    /**
     * Save current application state
     */
    saveCurrentState() {
        try {
            const state = {
                currentStep: this.currentStep,
                timestamp: new Date().toISOString(),
                version: '1.0.0'
            };

            saveToStorage('questionRandomizer_appState', state);
        } catch (error) {
            console.error('Error saving application state:', error);
        }
    }

    /**
     * Close all open modals
     */
    closeAllModals() {
        document.querySelectorAll('.question-modal').forEach(modal => {
            modal.remove();
        });
    }

    /**
     * Confirm and clear all data
     */
    confirmClearAllData() {
        const confirmed = confirm(
            'Are you sure you want to clear all data? This action cannot be undone.'
        );

        if (confirmed) {
            clearAllData();
            this.resetApplication();
        }
    }

    /**
     * Reset application to initial state
     */
    resetApplication() {
        // Reset current step
        this.currentStep = 'upload';
        this.goToStep('upload');

        // Clear file handler
        if (window.fileHandler) {
            fileHandler.clearFiles();
        }

        // Reset question manager
        if (window.questionManager) {
            questionManager.loadChapters([]);
        }

        // Reset paper generator
        if (window.paperGenerator) {
            paperGenerator.loadQuestions([]);
        }

        showNotification('Application reset successfully', 'success');
    }

    /**
     * Check if there are unsaved changes
     * @returns {boolean} True if there are unsaved changes
     */
    hasUnsavedChanges() {
        // Check if there are uploaded files that haven't been processed
        if (window.fileHandler && fileHandler.uploadedFiles.length > 0) {
            const hasUnprocessed = fileHandler.uploadedFiles.some(file => 
                file.status === 'pending' || file.status === 'processing'
            );
            if (hasUnprocessed) return true;
        }

        // Check if there are selected questions that haven't been generated
        if (window.questionManager && Object.keys(questionManager.selectionConfig).length > 0) {
            const hasSelections = Object.values(questionManager.selectionConfig).some(count => count > 0);
            if (hasSelections && this.currentStep !== 'generation') return true;
        }

        return false;
    }

    /**
     * Export application data
     */
    exportData() {
        try {
            const data = {
                chapters: loadFromStorage('questionRandomizer_chapters') || [],
                selectedQuestions: loadFromStorage('questionRandomizer_selectedQuestions') || [],
                paperConfig: loadFromStorage('questionRandomizer_paperConfig') || {},
                appState: loadFromStorage('questionRandomizer_appState') || {},
                exportDate: new Date().toISOString(),
                version: '1.0.0'
            };

            const dataStr = JSON.stringify(data, null, 2);
            const filename = `question_randomizer_backup_${new Date().toISOString().split('T')[0]}.json`;
            
            downloadTextFile(dataStr, filename, 'application/json');
            showNotification('Data exported successfully', 'success');

        } catch (error) {
            console.error('Error exporting data:', error);
            showNotification('Error exporting data', 'error');
        }
    }

    /**
     * Import application data
     * @param {File} file - JSON file to import
     */
    async importData(file) {
        try {
            const text = await file.text();
            const data = JSON.parse(text);

            // Validate data structure
            if (!data.version || !data.exportDate) {
                throw new Error('Invalid backup file format');
            }

            // Confirm import
            const confirmed = confirm(
                'This will replace all current data. Are you sure you want to continue?'
            );

            if (!confirmed) return;

            // Import data
            if (data.chapters) {
                saveToStorage('questionRandomizer_chapters', data.chapters);
            }
            if (data.selectedQuestions) {
                saveToStorage('questionRandomizer_selectedQuestions', data.selectedQuestions);
            }
            if (data.paperConfig) {
                saveToStorage('questionRandomizer_paperConfig', data.paperConfig);
            }
            if (data.appState) {
                saveToStorage('questionRandomizer_appState', data.appState);
            }

            // Reload application
            location.reload();

        } catch (error) {
            console.error('Error importing data:', error);
            showNotification('Error importing data. Please check the file format.', 'error');
        }
    }

    /**
     * Get application statistics
     * @returns {Object} Application statistics
     */
    getStatistics() {
        const chapters = loadFromStorage('questionRandomizer_chapters') || [];
        const selectedQuestions = loadFromStorage('questionRandomizer_selectedQuestions') || [];
        
        return {
            totalChapters: chapters.length,
            totalQuestions: chapters.reduce((sum, chapter) => sum + chapter.totalQuestions, 0),
            selectedQuestions: selectedQuestions.length,
            currentStep: this.currentStep,
            lastActivity: loadFromStorage('questionRandomizer_appState')?.timestamp || null
        };
    }
}

// Initialize application when DOM is loaded
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new QuestionRandomizerApp();
    
    // Make app globally available for debugging
    window.questionRandomizerApp = app;
    
    // Add some global utility functions
    window.exportData = () => app.exportData();
    window.resetApp = () => app.confirmClearAllData();
    window.getStats = () => app.getStatistics();
});

// Service Worker registration for PWA features (optional)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}


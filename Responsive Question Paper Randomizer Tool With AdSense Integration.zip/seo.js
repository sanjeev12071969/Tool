// SEO Optimization Script for Question Randomizer Tool

class SEOManager {
    constructor() {
        this.init();
    }

    /**
     * Initialize SEO optimizations
     */
    init() {
        this.addStructuredData();
        this.optimizeMetaTags();
        this.addCanonicalURL();
        this.setupAnalytics();
        this.addPreloadHints();
        this.optimizeImages();
    }

    /**
     * Add structured data (JSON-LD) for better search engine understanding
     */
    addStructuredData() {
        const structuredData = {
            "@context": "https://schema.org",
            "@type": "WebApplication",
            "name": "Question Paper Randomizer Tool",
            "description": "Professional question paper generation tool for educators and trainers. Create randomized question papers from Word documents with answers and explanations.",
            "url": window.location.origin,
            "applicationCategory": "EducationalApplication",
            "operatingSystem": "Web Browser",
            "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
            },
            "creator": {
                "@type": "Organization",
                "name": "Question Randomizer Team"
            },
            "featureList": [
                "Upload Word documents with questions",
                "Organize questions by chapters",
                "Smart randomization algorithms",
                "Generate Word format question papers",
                "Create answer keys with explanations",
                "Mobile-friendly responsive design",
                "Secure local processing"
            ],
            "screenshot": window.location.origin + "/assets/images/screenshot.png",
            "softwareVersion": "1.0.0",
            "datePublished": "2024-08-02",
            "dateModified": new Date().toISOString().split('T')[0],
            "inLanguage": "en-US",
            "isAccessibleForFree": true,
            "browserRequirements": "Requires JavaScript. Requires HTML5.",
            "softwareRequirements": "Modern web browser with JavaScript support"
        };

        // Add FAQ structured data
        const faqData = {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                {
                    "@type": "Question",
                    "name": "How do I upload question files?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "You can upload Word documents (.docx or .doc) by dragging and dropping them into the upload area or clicking the browse button. The tool will automatically parse questions, answers, and explanations from your documents."
                    }
                },
                {
                    "@type": "Question",
                    "name": "What file formats are supported?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "The tool supports Microsoft Word documents in .docx and .doc formats. Questions should be formatted with multiple choice options and include answers and explanations."
                    }
                },
                {
                    "@type": "Question",
                    "name": "Is my data secure?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Yes, all processing happens locally in your browser. Your question files and generated papers never leave your device, ensuring complete privacy and security."
                    }
                },
                {
                    "@type": "Question",
                    "name": "Can I customize the question paper format?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "Yes, you can customize the paper title, time duration, maximum marks, and instructions. The tool generates professional-looking question papers in Word format."
                    }
                },
                {
                    "@type": "Question",
                    "name": "How does the randomization work?",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "The tool uses advanced algorithms to randomly select questions from different chapters while ensuring fair distribution. You can specify how many questions to include from each chapter."
                    }
                }
            ]
        };

        // Add HowTo structured data
        const howToData = {
            "@context": "https://schema.org",
            "@type": "HowTo",
            "name": "How to Create Random Question Papers",
            "description": "Step-by-step guide to generate randomized question papers using the Question Randomizer Tool",
            "image": window.location.origin + "/assets/images/how-to-guide.png",
            "totalTime": "PT10M",
            "estimatedCost": {
                "@type": "MonetaryAmount",
                "currency": "USD",
                "value": "0"
            },
            "supply": [
                {
                    "@type": "HowToSupply",
                    "name": "Word documents with questions"
                },
                {
                    "@type": "HowToSupply",
                    "name": "Web browser with JavaScript"
                }
            ],
            "tool": [
                {
                    "@type": "HowToTool",
                    "name": "Question Randomizer Tool"
                }
            ],
            "step": [
                {
                    "@type": "HowToStep",
                    "name": "Upload Question Files",
                    "text": "Upload your Word documents containing objective questions with answers and explanations",
                    "image": window.location.origin + "/assets/images/step1.png",
                    "url": window.location.origin + "/#upload"
                },
                {
                    "@type": "HowToStep",
                    "name": "Select Questions",
                    "text": "Choose questions from different chapters and specify how many from each section",
                    "image": window.location.origin + "/assets/images/step2.png",
                    "url": window.location.origin + "/#selection"
                },
                {
                    "@type": "HowToStep",
                    "name": "Generate and Download",
                    "text": "Configure paper settings and download randomized question papers with answer keys",
                    "image": window.location.origin + "/assets/images/step3.png",
                    "url": window.location.origin + "/#generation"
                }
            ]
        };

        // Insert structured data into the page
        this.insertStructuredData('webapp-schema', structuredData);
        this.insertStructuredData('faq-schema', faqData);
        this.insertStructuredData('howto-schema', howToData);
    }

    /**
     * Insert structured data script into the page
     * @param {string} id - Script ID
     * @param {Object} data - Structured data object
     */
    insertStructuredData(id, data) {
        // Remove existing script if present
        const existingScript = document.getElementById(id);
        if (existingScript) {
            existingScript.remove();
        }

        const script = document.createElement('script');
        script.id = id;
        script.type = 'application/ld+json';
        script.textContent = JSON.stringify(data);
        document.head.appendChild(script);
    }

    /**
     * Optimize meta tags dynamically
     */
    optimizeMetaTags() {
        // Update page title based on current step
        this.updatePageTitle();

        // Add additional meta tags
        this.addMetaTag('robots', 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1');
        this.addMetaTag('googlebot', 'index, follow');
        this.addMetaTag('bingbot', 'index, follow');
        
        // Performance hints
        this.addMetaTag('dns-prefetch', 'https://fonts.googleapis.com');
        this.addMetaTag('dns-prefetch', 'https://cdnjs.cloudflare.com');
        this.addMetaTag('dns-prefetch', 'https://pagead2.googlesyndication.com');
        
        // Security
        this.addMetaTag('referrer', 'strict-origin-when-cross-origin');
        
        // Mobile optimization
        this.addMetaTag('mobile-web-app-capable', 'yes');
        this.addMetaTag('apple-mobile-web-app-capable', 'yes');
        this.addMetaTag('apple-mobile-web-app-status-bar-style', 'default');
        this.addMetaTag('apple-mobile-web-app-title', 'Question Randomizer');
        
        // Theme color
        this.addMetaTag('theme-color', '#3b82f6');
        this.addMetaTag('msapplication-TileColor', '#3b82f6');
    }

    /**
     * Add or update a meta tag
     * @param {string} name - Meta tag name
     * @param {string} content - Meta tag content
     */
    addMetaTag(name, content) {
        let meta = document.querySelector(`meta[name="${name}"]`);
        if (!meta) {
            meta = document.createElement('meta');
            meta.name = name;
            document.head.appendChild(meta);
        }
        meta.content = content;
    }

    /**
     * Update page title based on current application state
     */
    updatePageTitle() {
        const baseTitle = 'Question Paper Randomizer Tool';
        let currentTitle = baseTitle;

        // Get current step from app
        if (window.questionRandomizerApp) {
            const step = window.questionRandomizerApp.currentStep;
            switch (step) {
                case 'upload':
                    currentTitle = `Upload Files - ${baseTitle}`;
                    break;
                case 'selection':
                    currentTitle = `Select Questions - ${baseTitle}`;
                    break;
                case 'generation':
                    currentTitle = `Generate Paper - ${baseTitle}`;
                    break;
                default:
                    currentTitle = baseTitle;
            }
        }

        document.title = currentTitle;
        
        // Update Open Graph title
        let ogTitle = document.querySelector('meta[property="og:title"]');
        if (ogTitle) {
            ogTitle.content = currentTitle;
        }
    }

    /**
     * Add canonical URL
     */
    addCanonicalURL() {
        let canonical = document.querySelector('link[rel="canonical"]');
        if (!canonical) {
            canonical = document.createElement('link');
            canonical.rel = 'canonical';
            document.head.appendChild(canonical);
        }
        canonical.href = window.location.origin + window.location.pathname;
    }

    /**
     * Setup analytics and tracking
     */
    setupAnalytics() {
        // Google Analytics 4 (replace with your tracking ID)
        const GA_TRACKING_ID = 'G-XXXXXXXXXX';
        
        if (GA_TRACKING_ID !== 'G-XXXXXXXXXX') {
            // Load Google Analytics
            const script1 = document.createElement('script');
            script1.async = true;
            script1.src = `https://www.googletagmanager.com/gtag/js?id=${GA_TRACKING_ID}`;
            document.head.appendChild(script1);

            const script2 = document.createElement('script');
            script2.textContent = `
                window.dataLayer = window.dataLayer || [];
                function gtag(){dataLayer.push(arguments);}
                gtag('js', new Date());
                gtag('config', '${GA_TRACKING_ID}');
            `;
            document.head.appendChild(script2);
        }

        // Track custom events
        this.setupEventTracking();
    }

    /**
     * Setup event tracking for user interactions
     */
    setupEventTracking() {
        // Track file uploads
        document.addEventListener('fileUploaded', (e) => {
            this.trackEvent('file_upload', {
                file_count: e.detail.fileCount,
                total_size: e.detail.totalSize
            });
        });

        // Track question selection
        document.addEventListener('questionsSelected', (e) => {
            this.trackEvent('questions_selected', {
                question_count: e.detail.questionCount,
                chapter_count: e.detail.chapterCount
            });
        });

        // Track paper generation
        document.addEventListener('paperGenerated', (e) => {
            this.trackEvent('paper_generated', {
                paper_type: e.detail.paperType,
                question_count: e.detail.questionCount
            });
        });

        // Track downloads
        document.addEventListener('fileDownloaded', (e) => {
            this.trackEvent('file_download', {
                file_type: e.detail.fileType,
                file_name: e.detail.fileName
            });
        });
    }

    /**
     * Track custom events
     * @param {string} eventName - Event name
     * @param {Object} parameters - Event parameters
     */
    trackEvent(eventName, parameters = {}) {
        // Google Analytics 4
        if (typeof gtag !== 'undefined') {
            gtag('event', eventName, parameters);
        }

        // Console log for debugging
        console.log('Event tracked:', eventName, parameters);
    }

    /**
     * Add preload hints for better performance
     */
    addPreloadHints() {
        // Preload critical fonts
        this.addPreloadLink('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap', 'style');
        
        // Preload critical JavaScript libraries
        this.addPreloadLink('lib/jszip.min.js', 'script');
        this.addPreloadLink('lib/mammoth.min.js', 'script');
        
        // Preconnect to external domains
        this.addPreconnectLink('https://fonts.googleapis.com');
        this.addPreconnectLink('https://fonts.gstatic.com');
        this.addPreconnectLink('https://cdnjs.cloudflare.com');
    }

    /**
     * Add preload link
     * @param {string} href - Resource URL
     * @param {string} as - Resource type
     */
    addPreloadLink(href, as) {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.href = href;
        link.as = as;
        if (as === 'style') {
            link.onload = function() { this.rel = 'stylesheet'; };
        }
        document.head.appendChild(link);
    }

    /**
     * Add preconnect link
     * @param {string} href - Domain URL
     */
    addPreconnectLink(href) {
        const link = document.createElement('link');
        link.rel = 'preconnect';
        link.href = href;
        link.crossOrigin = 'anonymous';
        document.head.appendChild(link);
    }

    /**
     * Optimize images for better performance
     */
    optimizeImages() {
        // Add lazy loading to images
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            if (!img.hasAttribute('loading')) {
                img.loading = 'lazy';
            }
        });

        // Add intersection observer for advanced lazy loading
        if ('IntersectionObserver' in window) {
            this.setupAdvancedLazyLoading();
        }
    }

    /**
     * Setup advanced lazy loading with Intersection Observer
     */
    setupAdvancedLazyLoading() {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                        observer.unobserve(img);
                    }
                }
            });
        });

        // Observe images with data-src attribute
        document.querySelectorAll('img[data-src]').forEach(img => {
            imageObserver.observe(img);
        });
    }

    /**
     * Generate and update sitemap dynamically
     */
    generateSitemap() {
        const urls = [
            { loc: window.location.origin + '/', priority: '1.0', changefreq: 'weekly' },
            { loc: window.location.origin + '/#features', priority: '0.8', changefreq: 'monthly' },
            { loc: window.location.origin + '/#how-it-works', priority: '0.8', changefreq: 'monthly' },
            { loc: window.location.origin + '/#app-interface', priority: '0.9', changefreq: 'weekly' }
        ];

        const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map(url => `    <url>
        <loc>${url.loc}</loc>
        <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
        <changefreq>${url.changefreq}</changefreq>
        <priority>${url.priority}</priority>
    </url>`).join('\n')}
</urlset>`;

        return sitemap;
    }

    /**
     * Update meta description based on current content
     * @param {string} description - New description
     */
    updateMetaDescription(description) {
        let metaDesc = document.querySelector('meta[name="description"]');
        if (metaDesc) {
            metaDesc.content = description;
        }

        // Update Open Graph description
        let ogDesc = document.querySelector('meta[property="og:description"]');
        if (ogDesc) {
            ogDesc.content = description;
        }
    }

    /**
     * Add breadcrumb structured data
     * @param {Array} breadcrumbs - Breadcrumb items
     */
    addBreadcrumbData(breadcrumbs) {
        const breadcrumbData = {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": breadcrumbs.map((crumb, index) => ({
                "@type": "ListItem",
                "position": index + 1,
                "name": crumb.name,
                "item": crumb.url
            }))
        };

        this.insertStructuredData('breadcrumb-schema', breadcrumbData);
    }
}

// Initialize SEO manager when DOM is loaded
let seoManager;
document.addEventListener('DOMContentLoaded', () => {
    seoManager = new SEOManager();
    
    // Make SEO manager globally available
    window.seoManager = seoManager;
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SEOManager;
}

